
%{
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <stdbool.h>
#include <vector>
#include <string>
#include <iostream>
#include <string> 
#include <iomanip>
#include <locale>
#include <sstream>
#include <fstream>
using namespace std;
vector<string> tokens;
extern void yyerror(char *);
extern FILE *yyin;
extern int linenum;
extern int yylex();
int str_val[26];
ofstream myfile;
int cursor=0;

char *my_itoa(int num)
{
	char *str;
        printf(str, "%d", num);
        return str;
}

void file_writer ()
{
	myfile.open("output.txt");
}

void detect_leftmost_recursion()
{
	int size = tokens.size();
	vector<string> checks;
	
	/*for(int a=0; a<size; a++)
	{
		cout<<tokens[a]<<" "; 
	}
	*/
	int i=size-1;
	int cursor=0;
	while (i>0)
	{
			
		if(tokens[i]=="+")
		{
			if(tokens[i]=="+" && tokens[i+1]==tokens[i+3]) // if leftmos occurs
			{		//cout<<"buraya girecek"<<endl;
					string str= tokens[i+1];
					int pos = str.find(">");
					//cout<<"pos: "<<pos<<endl;
					string c = str.substr(1,pos-1);
					//cout<<"substr: "<<c<<endl;
					//char c = str[1]; //non terminal that occurs left_most recursion
					

					for(int j=i; j<size; j++) // leftmost gelmeden önce aynı non_terminale ait rule var mı?
					{
						//cout<<"buraya girecek"<<endl;	
						if(tokens[j]=="+")
						{
							if(tokens[j+1]==tokens[i+1] && tokens[j+1]!=tokens[j+3]) // rhs yi olduğu gibi al 
							{
								
								myfile<<tokens[i+1]<<" -> ";
								for(int k=j+3; k<=size; k++) // rhs i yazdırıyor
								{
									if(tokens[k]=="+")
									{	
										myfile<<"<"<<c<<"2>"<<"\n"; // NON2 yi ekliyor
										
										break;
									}
									if(k==size)
									{
										myfile<<"\n";
										break;
									}
									myfile<<tokens[k]<<" ";
								}
								
							}	
						}
					}
					for(int j=i-1; j>=0; j--)
					{
						
						if(tokens[j]=="+")
						{
							
							if(tokens[j+1]==tokens[i+1] && tokens[j+1]!=tokens[j+3]) // rhs yi olduğu gibi al 
							{
								
								myfile<<tokens[j+1]<<" -> ";
								for(int k=j+3; k<size; k++) // rhs i yazdırıyor
								{
									if(tokens[k]=="+")
									{	
										myfile<<"<"<<c<<"2>"<<"\n"; // NON2 yi ekliyor
						
										break;
									}
									myfile<<tokens[k]<<" ";
									
								}
								
								
							}
						}
					}
					myfile<<"<"<<c<<"2> -> "<<"epsilon"<<"\n";

					for(int j=i; j>=0; j--)  						
					{
					
						
						if(tokens[j]=="+" ) //buraya girmiyo bak
						{


							if (tokens[j+1]!=tokens[i+1])
							{
								//cout<<"bitt: "<<tokens[j+1]<<endl;
								break;
							}
							if(tokens[j+1]==tokens[j+3])
							{
								
								myfile<<"<"<<c<<"2> -> ";
								for(int k=j+4; k<size; k++) // left olan non dan sonra olan rhs i yazdırıyor
								{
									if(tokens[k]=="+")
									{
										myfile<<"<"<<c<<"2>"<<"\n";
										break;
									}
									myfile<<tokens[k]<<" ";
									
									if(k==size-1)
									{
										myfile<<"<"<<c<<"2>"<<"\n";
										break;
									}
									
								}
								
								
							}
							//cout << "j: "<<tokens[j+1]<<" i:"<<tokens[i+1]<<endl;

						}		
					}

					int yer=0;
					for(int j=i-1; j>=0; j--)		// i yi yeni non terminale kadar azalt	
					{
					
						if(tokens[j]=="+")
						{
							if(tokens[j+1]!=tokens[i+1])
							{
								for(int k=j+1; k<size; k++)
								{
									if(tokens[k]=="+" && tokens[k+1]==tokens[i+1])
										break;
								}		
								yer=j;
								break;
							}
							
						}
						cursor++;				
					}
					
					i=yer+1;
					
			}

			else // eğer elft_most değilse olduğu gibi yaz
			{  
				int count=0;
				for(int j=i; j>=0; j--) 
				{
					if(tokens[j]=="+")	
					{
						if(tokens[j+1]==tokens[i+1]) // aynı rule
						{
							count++;
						}
						else
							break;	
					
					}
						
				
				}


				int check_count=0;
				int left_flag=0;
				for(int j=i; j>=0; j--)
				{
					
					if(tokens[j] == "+")
					{
						if(count==check_count)	
						{
							break;
						}

						if(tokens[j+1] == tokens[j+3]) // if left recursion do nothing in else part
						{
							left_flag=1;
							break;
						}
						check_count++;
					}					
					
				}
				
				if(left_flag==0)
				{		
					check_count=0;
					
					
					int flag_check=0;
					for(int j=i; j>=0; j--)
					{
						if(tokens[j]=="+")
						{
							if(count==check_count)	
							{	
								//cout<<"count ı astı"<<endl;
								int flag_check=1;
								i=j+1;
								break;
							}
							if(flag_check==0)							
							{		
								for(int k=j+1; k<=size; k++)
								{
									if(tokens[k]=="+")
									{
										myfile<<"\n";
										break;
									}
									if(k==size)
									{
										myfile<<"\n";
										break;
									}
									
									myfile<<tokens[k]<<" ";
								}
								check_count++;	
							}			
						}
					}
				}
			}

		}
		i--;
		
	}
}

%}
%union
{
int number;
char *string;
}
%token <string> TERMINAL
%token <string> NON_TERMINAL
%token NEW_LINE
%token <string> OPERATOR
%type <string> rule_declaration
%type <string> right_side
%%

program:
	statements
	;

statements:
	statement statements
	|	
	statement
	;
	
statement:
	rule_declaration
	;

rule_declaration:
	NON_TERMINAL OPERATOR right_side NEW_LINE
	{

		tokens.insert(tokens.begin(),string($2));
		tokens.insert(tokens.begin(),string($1));
		int Number = linenum;       // number to be converted to a string
		string Result;          // string which will contain the result
		ostringstream convert;   // stream used for the conversion		
		convert << Number;      // insert the textual representation of 'Number' in the characters in the stream
		Result = convert.str(); // set 'Result' to the contents of the stream
		//cout<<Result<<endl;
		tokens.insert(tokens.begin(),string("+"));
			
		/*int size = tokens.size();
		int untill = cursor;
		
		if(tokens[1]!=tokens[3]) // if there is no leftmost recursion
		{	
			for(int i=0; i<size-untill; i++)
			{	
				if(tokens[i]=="+") i++;		
				myfile<<tokens[i]<<" ";
				cursor++;
				
			}
		}

		else // if there is a leftmost recursion
		{
			for(int i=0; i<size
				if(tokens[2+2]=="+") // if the rule has a single non_terminal or terminal 
		}
				
		myfile<<"\n";

		*/
		//printf(" <- %s\n" , $1);
		//myfile<<"<-"<<tokens[0]<<"\n";

	}
	;


right_side:
	NON_TERMINAL 
	{
		tokens.insert(tokens.begin(),string($1));
		//printf("%s " , $1);
		//myfile<<tokens[0]<<" ";

	}
	|
	NON_TERMINAL right_side 
	{
		tokens.insert(tokens.begin(),string($1));
		//printf("%s " , $1);
		//myfile<<tokens[0]<<" ";

	}
	|
	TERMINAL 
	{
		tokens.insert(tokens.begin(),string($1));
		//printf("%s " , $1);
		//myfile<<tokens[0]<<" ";

	}
	|
	TERMINAL right_side 
	{
		tokens.insert(tokens.begin(),string($1));
		//printf("%s " , $1);
		//myfile<<tokens[0]<<" ";

	}
	;



%%
void yyerror(char *s)
{
	fprintf(stderr, "error: %s\n",s);
}

int yywrap()
{
	return 1;
}

int main (int argc, char *argv[])
{
	/* Call the lexer, then quit. */
	{
		file_writer();
		yyin=fopen(argv[1],"r");
		yyparse();
		fclose(yyin);
		/*int size = tokens.size();
		for(int i=0; i<size; i++)
		{
			
			myfile<<tokens[i]<<" ";
		}
		

		/*
		int line=2;
		for(int i=0; i<size; i++)
		{	

			myfile<<tokens[i]<<" ";
			string s = tokens[i+1]; 
		        stringstream linenumber(s); 
		        int x = 0; 
		        linenumber >> x; 
			if(x==line)
			{
				myfile<<"\n";
				line++;
				i++;
			}
		
		}
		*/
		detect_leftmost_recursion();		
		myfile.close();
		return 0;
	}
}
