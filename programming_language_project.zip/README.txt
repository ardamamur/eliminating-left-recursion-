README DOCUMENT by ARDA BURAK MAMUR

Source code and created/developed files can be dound under "term_project" file in project directory.

CHECK TOKENIZATION

1. To check tokenization please run "lex project_lex.l" in "term_project" folder, so that "lex.yy.c" can be generated/updated/overwritten.    

2. To generate tokenizer executable run "make" comment in "term_project" folder,

3. "./<nameOfExec> <inputFile>" can be run via terminal to see the tokenization in the terminal directly.

Now it is done your output.txt file is generated regarding to your input file.